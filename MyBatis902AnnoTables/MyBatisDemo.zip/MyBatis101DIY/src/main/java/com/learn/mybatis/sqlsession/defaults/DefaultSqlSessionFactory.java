package com.learn.mybatis.sqlsession.defaults;

import com.learn.mybatis.cfg.Configuration;
import com.learn.mybatis.sqlsession.SqlSession;
import com.learn.mybatis.sqlsession.SqlSessionFactory;

/**
 * SqlSessionFactory接口的实现类
 */
public class DefaultSqlSessionFactory implements SqlSessionFactory {

    private Configuration cfg;

    public DefaultSqlSessionFactory(Configuration cfg) {
        this.cfg = cfg;
    }

    /**
     * 用于创建一个新的操作数据库对象
     * @return
     */
    public SqlSession openSession() {

        return new DefaultSqlSession(cfg);
    }
}

















