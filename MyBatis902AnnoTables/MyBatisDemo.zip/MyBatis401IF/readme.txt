动态SQL XML方式
    业务逻辑复杂时，我们的 SQL 是动态变化的

    在 映射配置 xml文件中 使用
        ·<if>
        ·<where>
        ·<foreach>
        ·<sql>