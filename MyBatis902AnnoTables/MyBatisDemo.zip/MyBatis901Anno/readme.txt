MyBatis 的单表 CRUD 注解使用

    resources下的UserDao.xml不在com/learn/dao和java保持一致，是无效的
    这里是在UserDao中，配置的 映射|操作 信息
